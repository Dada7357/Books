import XCTest

@testable import ApplicationTests

XCTMain([
    testCase(RouteTests.allTests),
    ])
