import App
import Dispatch
import XCTest

final class AppTests: XCTestCase {
    func testNothing() throws {
        XCTAssert(true)
    }

    static let allTests = [
        ("testNothing", testNothing)
    ]
}
